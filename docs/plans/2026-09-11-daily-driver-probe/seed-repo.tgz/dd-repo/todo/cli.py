"""Command-line interface for the todo store."""

from __future__ import annotations

import argparse
import sys

from todo.storage import TodoStore


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="todo")
    parser.add_argument("--store", default="todos.json")
    sub = parser.add_subparsers(dest="command", required=True)
    add = sub.add_parser("add")
    add.add_argument("text")
    sub.add_parser("list")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    store = TodoStore(args.store)
    if args.command == "add":
        todo = store.add(args.text)
        print(f"added #{todo['id']}: {todo['text']}")
    elif args.command == "list":
        for todo in store.list():
            mark = "x" if todo["done"] else " "
            print(f"[{mark}] #{todo['id']} {todo['text']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
