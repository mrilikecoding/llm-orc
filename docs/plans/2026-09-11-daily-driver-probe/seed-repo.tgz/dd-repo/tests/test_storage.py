from todo.storage import TodoStore


def test_add_assigns_incrementing_ids(tmp_path):
    store = TodoStore(tmp_path / "t.json")
    assert store.add("a")["id"] == 1
    assert store.add("b")["id"] == 2


def test_list_returns_added_todos(tmp_path):
    store = TodoStore(tmp_path / "t.json")
    store.add("a")
    assert [t["text"] for t in store.list()] == ["a"]


def test_complete_marks_done(tmp_path):
    store = TodoStore(tmp_path / "t.json")
    store.add("a")
    assert store.complete(1)["done"] is True
