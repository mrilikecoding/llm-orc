# todo-cli

A small JSON-backed todo list with a command-line interface.

- `todo/storage.py` — `TodoStore`: add, list, complete
- `todo/cli.py` — `todo add <text>`, `todo list`
